package salted.packedup.common.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;
import salted.packedup.client.DrumKnockTracker;
import salted.packedup.common.block.entity.DrumBarrelBlockEntity;
import salted.packedup.common.registry.PURegistry;
import salted.packedup.common.registry.PUSounds;
import salted.packedup.common.tag.PUTags;

public class DrumBarrelBlock extends BaseEntityBlock {
    public DrumBarrelBlock(Properties props) { super(props); }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return PURegistry.DRUM_BARREL_ENTITY.create(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (FluidUtil.interactWithFluidHandler(player, hand, level, pos, hit.getDirection())) {
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        ItemStack held = player.getItemInHand(hand);
        ItemStack other = player.getItemInHand(hand == InteractionHand.MAIN_HAND
                ? InteractionHand.OFF_HAND
                : InteractionHand.MAIN_HAND);

        if (held.is(PUTags.DRUM_STRIKERS)) {
            knock(level, pos, false);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        if (held.isEmpty() && other.isEmpty()) {
            knock(level, pos, true);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        return InteractionResult.PASS;
    }

    private void knock(Level level, BlockPos pos, boolean bareHand) {
        if (level.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> DrumKnockTracker.mark(pos));
            return;
        }

        float fill = 0.0F;
        if (level.getBlockEntity(pos) instanceof DrumBarrelBlockEntity drum) {
            fill = Mth.clamp(drum.getTank().getFluidAmount() / (float) DrumBarrelBlockEntity.CAPACITY, 0.0F, 1.0F);
        }

        float pitch = 1.25F - (fill * 0.5F);
        float master = bareHand ? 0.4F : 0.8F;
        if (bareHand) pitch -= 0.1F;

        // equal-power crossfade, so the pair keeps a steady loudness across the range
        float angle = fill * (float) (Math.PI / 2.0);
        float emptyGain = Mth.cos(angle);
        float fullGain = Mth.sin(angle);

        if (emptyGain > 0.01F) {
            level.playSound(null, pos, PUSounds.DRUM_KNOCK_EMPTY.get(), SoundSource.BLOCKS, master * emptyGain, pitch);
        }
        if (fullGain > 0.01F) {
            level.playSound(null, pos, PUSounds.DRUM_KNOCK_FULL.get(), SoundSource.BLOCKS, master * fullGain, pitch);
        }
    }
}

package salted.packedup.data.models.builders.blocks;

import net.minecraft.world.level.block.Block;
import net.minecraftforge.client.model.generators.BlockModelBuilder;
import salted.packedup.data.models.PUBlockStates;
import salted.packedup.data.models.builders.PUBlockBuilder;

import static salted.packedup.data.utils.NameUtils.*;

public class ContainerModelBuilder {
    private final PUBlockBuilder provider;

    public ContainerModelBuilder(PUBlockStates provider) {
        this.provider = provider;
    }

    public void simpleBasket(Block block) {
        String name = blockName(block);
        String blockModel = basketLocation(name).toString();

        provider.simpleBlock(block, provider.models().withExistingParent(blockModel, "cube_bottom_top")
                .texture("particle", basketLocation(name + "_top"))
                .texture("bottom", basketLocation("basket_bottom"))
                .texture("side", basketLocation(name + "_side"))
                .texture("top", basketLocation(name + "_top")));
    }

    public void simpleBarrel(Block block) {
        String name = blockName(block);
        String blockModel = barrelLocation(name).toString();

        provider.simpleBlock(block, provider.models().withExistingParent(blockModel, "cube_bottom_top")
                .texture("particle", barrelLocation(name + "_top"))
                .texture("bottom", mcBlockLocation("barrel_bottom"))
                .texture("side", mcBlockLocation("barrel_side"))
                .texture("top", barrelLocation(name + "_top")));
    }

    public void simpleDrumBarrel(Block block) {
        String name = blockName(block);
        String texture = nameFromSplit(name, "_barrel", true);
        String blockModel = drumLocation(name).toString();

        provider.simpleBlock(block, provider.models().withExistingParent(blockModel, "cube_bottom_top")
                .texture("side", drumLocation(texture + "_side"))
                .texture("top", drumLocation(texture + "_top"))
                .texture("bottom", drumLocation(texture + "_bottom")));
    }

    public BlockModelBuilder resourceBag(Block block, boolean alt) {
        String name = blockName(block);
        String resource = nameFromSplit(name, "_bag", true);
        String blockModel = bagLocation(name).toString();

        if (alt) {
            return provider.models().withExistingParent(blockModel, provider.parent("bag/template/bag"))
                    .texture("top", bagLocation(name + "_top"));
        }
        return provider.models().withExistingParent(blockModel, provider.parent("bag/template/resource_bag"))
                .texture("pile", bagLocation("pile/" + resource + "_pile"));
    }

    public void simpleBag(Block block) {
        String name = blockName(block);
        String blockModel = bagLocation(name).toString();

        provider.simpleBlock(block, provider.models().withExistingParent(blockModel, provider.parent("bag/template/bag"))
                .texture("top", bagLocation(name + "_top")));
    }
}

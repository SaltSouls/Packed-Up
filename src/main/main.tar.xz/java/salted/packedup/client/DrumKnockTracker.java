package salted.packedup.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/**
 * Remembers the last drum the player knocked, so the gauge overlay can show the
 * exact fill for a short while afterwards. Client only, no packets needed: the
 * interaction runs on both sides.
 */
public class DrumKnockTracker {
    /**
     * How long the detailed readout stays up, in ticks.
     */
    private static final long DURATION = 100L;

    private static BlockPos knocked;
    private static long gameTime;

    public static void mark(BlockPos pos) {
        Level level = Minecraft.getInstance().level;
        if (level == null) return;

        knocked = pos.immutable();
        gameTime = level.getGameTime();
    }

    public static boolean isRecent(BlockPos pos) {
        Level level = Minecraft.getInstance().level;
        if (knocked == null || level == null) return false;

        return knocked.equals(pos) && level.getGameTime() - gameTime <= DURATION;
    }
}
package salted.packedup.client.events;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientTooltipComponentFactoriesEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import salted.packedup.PackedUp;
import salted.packedup.client.tooltip.ClientDrumTooltip;
import salted.packedup.client.tooltip.DrumTooltip;

@Mod.EventBusSubscriber(modid = PackedUp.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class PUTooltipComponents {

    @SubscribeEvent
    public static void registerTooltips(RegisterClientTooltipComponentFactoriesEvent event) {
        event.register(DrumTooltip.class, ClientDrumTooltip::new);
    }
}

package salted.packedup.client.events;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fml.common.Mod;
import salted.packedup.PackedUp;
import salted.packedup.client.DrumKnockTracker;
import salted.packedup.client.tooltip.ClientDrumTooltip;
import salted.packedup.client.tooltip.DrumTooltip;
import salted.packedup.common.block.entity.DrumBarrelBlockEntity;
import salted.packedup.common.registry.PURegistry;

@Mod.EventBusSubscriber(modid = PackedUp.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class PUGaugeOverlay {

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (event.getOverlay() != VanillaGuiOverlay.CROSSHAIR.type()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;

        boolean holding = mc.player.getMainHandItem().is(PURegistry.GAUGE.get())
                || mc.player.getOffhandItem().is(PURegistry.GAUGE.get());
        if (!holding) return;

        if (!(mc.hitResult instanceof BlockHitResult hit)) return;
        if (!(mc.level.getBlockEntity(hit.getBlockPos()) instanceof DrumBarrelBlockEntity drum)) return;

        boolean detailed = DrumKnockTracker.isRecent(hit.getBlockPos());
        render(event.getGuiGraphics(), mc, drum.getTank().getFluid(), detailed);
    }

    private static void render(GuiGraphics graphics, Minecraft mc, FluidStack fluid, boolean detailed) {
        Font font = mc.font;
        ClientDrumTooltip content = new ClientDrumTooltip(new DrumTooltip(fluid, detailed));

        int width = content.getWidth(font);
        int height = content.getHeight();
        int x = (graphics.guiWidth() - width) / 2;
        int y = graphics.guiHeight() / 2 + 14;

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 400.0F);

        TooltipRenderUtil.renderTooltipBackground(graphics, x, y, width, height, 0);
        content.renderAll(font, graphics, x, y);

        graphics.pose().popPose();
    }
}
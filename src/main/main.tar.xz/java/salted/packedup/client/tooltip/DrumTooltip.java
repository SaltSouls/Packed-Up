package salted.packedup.client.tooltip;

import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraftforge.fluids.FluidStack;

/**
 * @param fluid    the drum's current contents
 * @param detailed whether to show the amount and fill bar, shown only after the drum is knocked
 */
public record DrumTooltip(FluidStack fluid, boolean detailed) implements TooltipComponent {

}

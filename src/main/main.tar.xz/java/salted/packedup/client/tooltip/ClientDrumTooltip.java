package salted.packedup.client.tooltip;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Matrix4f;
import salted.packedup.common.block.entity.DrumBarrelBlockEntity;

public class ClientDrumTooltip implements ClientTooltipComponent {
    private static final int ICON = 16;
    private static final int BAR_HEIGHT = 8;
    private static final int MIN_WIDTH = 76;
    private static final int GAP = 2;
    private static final int AMOUNT_COLOR = 0x555555;

    private final FluidStack fluid;
    private final boolean detailed;

    public ClientDrumTooltip(DrumTooltip tooltip) {
        this.fluid = tooltip.fluid();
        this.detailed = tooltip.detailed();
    }

    // ============================================================
    // Lines
    // ============================================================
    /** Empty drums say so; otherwise the full registry id, e.g. {@code minecraft:lava}. */
    private Component name() {
        if (fluid.isEmpty()) return Component.translatable("tooltip.packedup.drum_barrel.empty");

        ResourceLocation id = ForgeRegistries.FLUIDS.getKey(fluid.getFluid());
        if (id == null) return fluid.getDisplayName();

        return Component.literal(id.toString());
    }

    private Component amount() {
        return Component.translatable("tooltip.packedup.drum_barrel.amount",
                String.format("%,d", fluid.getAmount()),
                String.format("%,d", DrumBarrelBlockEntity.CAPACITY));
    }

    // ============================================================
    // Layout
    //
    // An empty drum has no icon and no id line, so the whole block collapses
    // to a single line rather than leaving a hole where the sprite would be.
    // ============================================================
    private int iconWidth() {
        return fluid.isEmpty() ? 0 : ICON + 4;
    }

    /** Height of the first row: the icon with the name beside it, or just the name. */
    private int nameRowHeight(Font font) {
        return fluid.isEmpty() ? font.lineHeight : Math.max(ICON, font.lineHeight);
    }

    /** Y offset of the amount line. Only drawn when detailed. */
    private int amountLineY(Font font) {
        return nameRowHeight(font) + GAP;
    }

    private int amountWidth(Font font) {
        return font.width(amount());
    }

    /** Y offset of the fill bar. Only drawn when detailed. */
    private int barY(Font font) {
        return amountLineY(font) + font.lineHeight + GAP;
    }

    @Override
    public int getWidth(Font font) {
        int nameRow = iconWidth() + font.width(name());
        int amountRow = detailed ? amountWidth(font) : 0;

        return Math.max(MIN_WIDTH, Math.max(nameRow, amountRow));
    }

    @Override
    public int getHeight() {
        Font font = font();
        if (detailed) return barY(font) + BAR_HEIGHT;
        return nameRowHeight(font);
    }

    private static Font font() {
        return Minecraft.getInstance().font;
    }

    // ============================================================
    // Rendering
    // ============================================================
    /** Draws the whole tooltip body at the given content origin. Used by the gauge overlay. */
    public void renderAll(Font font, GuiGraphics graphics, int x, int y) {
        int nameY = y + (nameRowHeight(font) - font.lineHeight) / 2;
        if (fluid.isEmpty()) {
            // nothing to sit beside, so centre it rather than leaving it adrift on the left
            int centred = x + (getWidth(font) - font.width(name())) / 2;
            graphics.drawString(font, name(), centred, nameY, 0xFFFFFF);
        } else {
            graphics.drawString(font, name(), x + iconWidth(), nameY, 0xFFFFFF);
        }

        if (detailed) {
            drawAmount(font, graphics, x, y);
        }
        renderImage(font, x, y, graphics);
    }

    /** Centred and dark, so it reads as a secondary line under the name. */
    private void drawAmount(Font font, GuiGraphics graphics, int x, int y) {
        int drawX = x + (getWidth(font) - amountWidth(font)) / 2;
        graphics.drawString(font, amount(), drawX, y + amountLineY(font), AMOUNT_COLOR, false);
    }

    @Override
    public void renderText(Font font, int x, int y, Matrix4f matrix, MultiBufferSource.BufferSource buffer) {
        float nameY = y + (nameRowHeight(font) - font.lineHeight) / 2F;
        float nameX = fluid.isEmpty()
                ? x + (getWidth(font) - font.width(name())) / 2F
                : x + iconWidth();
        font.drawInBatch(name(), nameX, nameY, 0xFFFFFF, true,
                matrix, buffer, Font.DisplayMode.NORMAL, 0, 0xF000F0);

        if (detailed) {
            float amountX = x + (getWidth(font) - amountWidth(font)) / 2F;
            font.drawInBatch(amount(), amountX, y + amountLineY(font), AMOUNT_COLOR, false,
                    matrix, buffer, Font.DisplayMode.NORMAL, 0, 0xF000F0);
        }
    }

    @Override
    public void renderImage(Font font, int x, int y, GuiGraphics graphics) {
        TextureAtlasSprite sprite = null;
        if (!fluid.isEmpty()) {
            IClientFluidTypeExtensions ext = IClientFluidTypeExtensions.of(fluid.getFluid());
            sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(ext.getStillTexture(fluid));
            setTint(graphics, ext.getTintColor(fluid));
            graphics.blit(x, y, 0, ICON, ICON, sprite);
            clearTint(graphics);
        }

        if (!detailed) return;

        int width = getWidth(font);
        int barTop = y + barY(font);

        // recessed backdrop, so the bar reads as a gauge rather than a floating strip
        graphics.fill(x, barTop, x + width, barTop + BAR_HEIGHT, 0xFF1A1A1A);
        graphics.fill(x, barTop, x + width, barTop + 1, 0xFF0D0D0D);

        if (fluid.isEmpty() || sprite == null) return;

        float fill = Mth.clamp(fluid.getAmount() / (float) DrumBarrelBlockEntity.CAPACITY, 0.0F, 1.0F);
        int innerW = width - 2;
        int innerH = BAR_HEIGHT - 2;
        int filled = Math.round(innerW * fill);
        if (filled <= 0) return;

        // tile the sprite at its native size and clip it to the filled portion
        setTint(graphics, IClientFluidTypeExtensions.of(fluid.getFluid()).getTintColor(fluid));
        int inset = (16 - innerH) / 2;   // centre the visible band in the sprite
        graphics.enableScissor(x + 1, barTop + 1, x + 1 + filled, barTop + 1 + innerH);
        for (int dx = 0; dx < filled; dx += 16) {
            graphics.blit(x + 1 + dx, barTop + 1 - inset, 0, 16, 16, sprite);
        }
        graphics.disableScissor();
        clearTint(graphics);
    }

    private static void setTint(GuiGraphics graphics, int tint) {
        graphics.setColor(
                (tint >> 16 & 0xFF) / 255.0F,
                (tint >> 8 & 0xFF) / 255.0F,
                (tint & 0xFF) / 255.0F,
                1.0F);
    }

    private static void clearTint(GuiGraphics graphics) {
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }
}
